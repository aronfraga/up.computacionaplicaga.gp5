#!/bin/bash

function show_help() {
    echo "Uso: backup_full.sh [origen] [destino]"
    echo "Realiza el backup del directorio de origen en el destino especificado."
    echo "Opciones:"
    echo "  -h   Muestra esta ayuda y sale"
    exit 0
}

if [[ $1 == "-h" ]]; then
    show_help
fi

if [[ -z "$1" || -z "$2" ]]; then
    echo "Error: Se requieren ambos argumentos [origen] y [destino]"
    exit 1
fi

ORIGEN="$1"
DESTINO="$2"

if [[ ! -d "$ORIGEN" ]]; then
    echo "Error: El directorio origen no existe"
    exit 1
fi

if [[ ! -d "$DESTINO" ]]; then
    echo "Error: El directorio destino no existe"
    exit 1
fi

FECHA=$(date +"%Y%m%d")
NOMBRE_BACKUP="$(basename "$ORIGEN")_bkp_${FECHA}.tar.gz"
DESTINO_BACKUP="${DESTINO}/${NOMBRE_BACKUP}"

tar -czf "$DESTINO_BACKUP" -C "$(dirname "$ORIGEN")" "$(basename "$ORIGEN")"

if [[ $? -eq 0 ]]; then
    echo "Backup completado: $DESTINO_BACKUP"
else
    echo "Error: Falló la creación del backup"
    exit 1
fi
